#!/usr/bin/env bash
# ============================================================================
#  Elytrix — сороконожка над головой, маска убрана (v28)
# ----------------------------------------------------------------------------
#  Что делает:
#    * кладёт ElytrixFreakModel 3.7.0 (меню без кнопки «Назад», «Снять всё»
#      внизу по центру: крылья, нимб, кагуне, сороконожка; маска удалена);
#    * чинит главное: у сороконожки теперь есть свои модели и текстура
#      (assets/modelengine/items|models/elytrix_centipede + текстура) и
#      исправленный blueprint — без файлов в ресурспаке модель не рисуется
#      вообще, даже если плагин её создал;
#    * обновляет ресурспак и ElytrixRP/config.yml (новый SHA-1);
#    * печатает контрольные суммы, чтобы можно было проверить руками.
#
#  Запуск:  bash install.sh [/root/RW_GRIEF]        (sh install.sh тоже работает)
# ============================================================================
if [ -z "${BASH_VERSION:-}" ]; then
    exec /bin/bash "$0" "$@"
fi
set -euo pipefail

DIR="${1:-/root/RW_GRIEF}"
SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
RP_NAME="Elytrix-RP-1.21.zip"

say()  { printf '\033[1m==> %s\033[0m\n' "$*"; }
ok()   { printf '    \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '    \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '\033[31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

say "1/5  Проверки"
[ -d "$DIR" ] || die "нет каталога сервера: $DIR"
[ -f "$SELF_DIR/plugins/ElytrixFreakModel.jar" ] || die "в архиве нет plugins/ElytrixFreakModel.jar"
[ -f "$SELF_DIR/rp/$RP_NAME" ] || die "в архиве нет rp/$RP_NAME"
ok "каталог сервера: $DIR"
if pgrep -af 'java.*-jar (server|leaf|paper)\.jar' >/dev/null 2>&1; then
    warn "сервер, похоже, запущен — файлы заменятся, но изменения подхватит только restart"
fi

say "2/5  Плагин аксессуаров"
install -m 644 "$SELF_DIR/plugins/ElytrixFreakModel.jar" "$DIR/plugins/ElytrixFreakModel.jar"
ok "plugins/ElytrixFreakModel.jar  $(sha256sum "$DIR/plugins/ElytrixFreakModel.jar" | cut -d' ' -f1)"

say "3/5  Ресурспак"
mkdir -p "/root/RP" 2>/dev/null || true
if [ -w /root/RP ] || [ "$(id -u)" = "0" ]; then
    install -m 644 "$SELF_DIR/rp/$RP_NAME" "/root/RP/$RP_NAME"
    ok "/root/RP/$RP_NAME"
fi
mkdir -p "$DIR/rp"
install -m 644 "$SELF_DIR/rp/$RP_NAME" "$DIR/rp/$RP_NAME"
ok "$DIR/rp/$RP_NAME"
NEW_SHA1="$(sha1sum "$DIR/rp/$RP_NAME" | cut -d' ' -f1)"

say "4/5  ElytrixRP/config.yml"
CONFIG="$DIR/plugins/ElytrixRP/config.yml"
mkdir -p "$DIR/plugins/ElytrixRP"
if [ -f "$CONFIG" ]; then
    sed -i -E "s|^([[:space:]]*sha1[[:space:]]*:).*|\1 \"$NEW_SHA1\"|" "$CONFIG"
    ok "sha1 в конфиге обновлён (остальные настройки не тронуты)"
else
    install -m 644 "$SELF_DIR/plugins/ElytrixRP/config.yml" "$CONFIG"
    ok "конфиг установлен"
fi

say "5/5  Модели ModelEngine"
if [ -d "$SELF_DIR/plugins/ModelEngine" ]; then
    rm -rf "$DIR/plugins/ModelEngine/blueprints/elytrix_kaneki_eyepatch.bbmodel" \
           "$DIR/plugins/ModelEngine/resource pack/assets/modelengine/items/elytrix_kaneki_eyepatch" \
           "$DIR/plugins/ModelEngine/resource pack/assets/modelengine/models/elytrix_kaneki_eyepatch" \
           "$DIR/plugins/ModelEngine/resource pack/assets/modelengine/textures/entity/models/elytrix_kaneki_eyepatch.png" \
           "$DIR/plugins/ModelEngine/resource pack/assets/reallyworld/equipment/kaneki_eyepatch.json" \
           "$DIR/plugins/ModelEngine/resource pack/assets/reallyworld/items/kaneki_eyepatch_icon.json" \
           "$DIR/plugins/ModelEngine/resource pack/assets/reallyworld/models/item/freak/kaneki_eyepatch_icon.json" \
           "$DIR/plugins/ModelEngine/resource pack/assets/reallyworld/textures/entity/equipment/humanoid/kaneki_eyepatch.png" \
           "$DIR/plugins/ModelEngine/resource pack/assets/reallyworld/textures/item/freak/kaneki_eyepatch_icon.png" 2>/dev/null || true
    cp -a "$SELF_DIR/plugins/ModelEngine/." "$DIR/plugins/ModelEngine/"
    ok "blueprints и assets обновлены (остатки маски убраны)"
fi

printf '\n'
printf '  Ресурспак:  %s\n' "$NEW_SHA1"
printf '  Плагин:     %s\n' "$(sha256sum "$DIR/plugins/ElytrixFreakModel.jar" | cut -d' ' -f1)"
printf '  Версия:     %s\n' "$(unzip -p "$DIR/plugins/ElytrixFreakModel.jar" plugin.yml | grep -m1 '^version' | cut -d' ' -f2)"
printf '\n'
printf '  Дальше:  restart  (или stop → bash start.sh)\n'
printf '  Проверка в логе:  grep -iE "ElytrixFreakModel|ModelEngine" logs/latest.log | tail -20\n'

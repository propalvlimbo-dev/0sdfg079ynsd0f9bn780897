Elytrix — сороконожка v1 (полная замена)
========================================

Что внутри:
  blueprints/elytrix_centipede.bbmodel   новая модель (Blockbench 4.10, ModelEngine 4.1.0)
  textures/elytrix_centipede.png         новая текстура 128x128
  preview.png                            как выглядит (3 ракурса)

Модель: 119 кубов, 11 костей — body_root, c1..c9, head. Имена и пивоты
совпадают со старой моделью, поэтому плагин ElytrixFreakModel продолжает
находить те же кости и его анимация обхода вокруг игрока работает как была.

Установка:
  1) бэкап:
     cp -a /root/RW_GRIEF/plugins/ModelEngine/blueprints/elytrix_centipede.bbmodel \
           /root/RW_GRIEF/plugins/ModelEngine/blueprints/elytrix_centipede.bbmodel.bak
  2) положить .bbmodel и .png по путям из архива
  3) в игре или консоли: /meg reload      (ModelEngine пересоберёт ресурспак)
  4) перезапуск сервера
  5) обновить sha1 нового ресурспака в plugins/ElytrixRP/config.yml

Анимации в модели: idle (60 тиков, покачивание) и crawl (120 тиков, волна
по сегментам). Плагин двигает кости сам через ManualAnimator, поэтому
в игре работает его вариант; эти две — для Blockbench и для случаев,
когда модель проигрывается через ModelEngine напрямую.

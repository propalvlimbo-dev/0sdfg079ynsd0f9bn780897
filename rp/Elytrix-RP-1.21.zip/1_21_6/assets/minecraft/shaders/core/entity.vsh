#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
out float elytrixHideRadius;
out float elytrixEyeDist;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    ivec3 elytrixTint = ivec3(Color.rgb * 255.0 + 0.5);
    vec4 baseColor = Color;
    elytrixHideRadius = 0.0;
    if (abs(ProjMat[2][3]) > 1e-4) {
        if (elytrixTint == ivec3(252, 254, 253)) {
            elytrixHideRadius = 1.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (elytrixTint == ivec3(252, 253, 254)) {
            elytrixHideRadius = 2.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
    elytrixEyeDist = length((ModelViewMat * vec4(Position, 1.0)).xyz);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#ifdef NO_CARDINAL_LIGHTING
    vertexColor = baseColor;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, baseColor);
#endif
#ifndef EMISSIVE
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
#endif
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
}

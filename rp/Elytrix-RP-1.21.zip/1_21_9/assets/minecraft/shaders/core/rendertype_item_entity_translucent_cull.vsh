#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out float elytrixHideRadius;
out float elytrixEyeDist;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    ivec3 elytrixTint = ivec3(Color.rgb * 255.0 + 0.5);
    vec4 baseColor = Color;
    elytrixHideRadius = 0.0;
    if (abs(ProjMat[2][3]) > 1e-4) {
        if (elytrixTint == ivec3(252, 254, 253)) {
            elytrixHideRadius = 1.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        } else if (elytrixTint == ivec3(252, 253, 254)) {
            elytrixHideRadius = 2.85;
            baseColor = vec4(1.0, 1.0, 1.0, Color.a);
        }
    }
    elytrixEyeDist = length((ModelViewMat * vec4(Position, 1.0)).xyz);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, baseColor) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
}

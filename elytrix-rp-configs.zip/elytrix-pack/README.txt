Elytrix — ресурспак + конфиги ядра + start.sh
=============================================

Elytrix-RP-1.21.zip
    Ресурспак. SHA-1 c0e0837e9abd41180cd06a1acd904649e96ea87b
    Кидать в папку ресурспаков клиента или в плагин ресурспака.
    Обычно серверный путь: /root/RW_GRIEF/plugins/<плагин>/  (см. настройки плагина)

configs/
    Конфиги ядра Leaf 1.21.11 + start.sh. Раскладываются в КОРЕНЬ сервера:

        configs/config/*.yml      ->  <сервер>/config/
        configs/bukkit.yml        ->  <сервер>/bukkit.yml
        configs/spigot.yml        ->  <сервер>/spigot.yml
        configs/start.sh          ->  <сервер>/start.sh   (chmod +x)

    Внутри: paper-global.yml, paper-world-defaults.yml, leaf-global.yml,
    gale-global.yml, gale-world-defaults.yml.

    start.sh: G1 с целью паузы 200 мс, heap считается от памяти машины,
    GC-лог в logs/gc.log, авторестарт после падения, без рестарта после stop.
    Флагов MaxDirectMemorySize / MaxMetaspaceSize в нём нет специально.

Установка одной командой (на сервере):
    cp -a configs/config/* /root/RW_GRIEF/config/ && cp -a configs/bukkit.yml configs/spigot.yml configs/start.sh /root/RW_GRIEF/ && chmod +x /root/RW_GRIEF/start.sh

Перед копированием сделай бэкап: cp -a /root/RW_GRIEF/config /root/RW_GRIEF/config.bak
